package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static Utilites.Utility.findWebElement;
import static Utilites.Utility.getText;

public class P06_FinishingOrderPage {
    private final WebDriver driver;
    private final By thanksMessage = By.className("complete-header");
    public P06_FinishingOrderPage(WebDriver driver) {
        this.driver=driver;
    }
    public boolean checkVisibilityOfThanksMessage() {

        return getText(driver,thanksMessage).equals("Thank you for your order!");//findWebElement(driver, thanksMessage).isDisplayed();
    }

}
